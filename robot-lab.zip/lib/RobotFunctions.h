#ifndef RobotFunctions_h
#define RobotFunctions_h

#include <Arduino.h>

class RobotFunctions {
public:
    // Конструктор
    RobotFunctions(int l_dir_pin, int l_speed_pin, int r_dir_pin, int r_speed_pin, 
                  int l_line_pin, int r_line_pin, int buzzer_pin,
                  int left_phase_a_pin, int left_phase_b_pin,
                  int right_phase_a_pin, int right_phase_b_pin,
                  int gray_l, int gray_r);

    // Основные функции движения
    void go(long l_speed, long r_speed);
    void stopp();
    void reset_enc();
    void go_n_tick(long n);
    void go_n_mm(long n);
    void turn_l_n_tick(long n);
    void turn_l_n_grad(long n);
    void turn_r_n_tick(long n);
    void turn_r_n_grad(long n);
    void sinhron(long n, int speed, float k = 0.2);
    void sinhron_mm(long mm, int speed, float k = 0.2);
    void stop_enc(float k = 0.2);

    // Функции для работы с датчиками линии
    bool left_line();
    bool right_line();
    void left_sens(int speed, float k = 0.25);
    void prop(int speed, float pk = 0.2);
    void go_to(int n, int speed = 70);
    void turn_r(int n);
    void go_line_n_mm(long n, int speed);
    void go_back_n_cross(int num);

    // Функции для звука
    void playMelody();

    // Переменные энкодеров
    volatile long left_curr_pos;
    volatile long right_curr_pos;
    long left_targ_pos;
    long right_targ_pos;

private:
    // Пины
    int _l_dir, _l_speed, _r_dir, _r_speed;
    int _l_line, _r_line;
    int _buzzer_pin;
    int _left_phase_a, _left_phase_b;
    int _right_phase_a, _right_phase_b;
    int _gray_l, _gray_r;

    // Вспомогательные функции
    void left_enc_phase_a();
    void right_enc_phase_a();
    static void left_enc_handler();
    static void right_enc_handler();
    
    // Статические переменные для обработчиков прерываний
    static RobotFunctions* instance;
};

#endif