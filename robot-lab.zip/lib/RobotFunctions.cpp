#include "RobotFunctions.h"
#include "pitches.h"

// Инициализация статического указателя
RobotFunctions* RobotFunctions::instance = nullptr;

// Конструктор
RobotFunctions::RobotFunctions(int l_dir_pin, int l_speed_pin, int r_dir_pin, int r_speed_pin, 
                             int l_line_pin, int r_line_pin, int buzzer_pin,
                             int left_phase_a_pin, int left_phase_b_pin,
                             int right_phase_a_pin, int right_phase_b_pin,
                             int gray_l, int gray_r) :
    _l_dir(l_dir_pin), _l_speed(l_speed_pin), _r_dir(r_dir_pin), _r_speed(r_speed_pin),
    _l_line(l_line_pin), _r_line(r_line_pin), _buzzer_pin(buzzer_pin),
    _left_phase_a(left_phase_a_pin), _left_phase_b(left_phase_b_pin),
    _right_phase_a(right_phase_a_pin), _right_phase_b(right_phase_b_pin),
    _gray_l(gray_l), _gray_r(gray_r),
    left_curr_pos(0), right_curr_pos(0), left_targ_pos(0), right_targ_pos(0) {
    
    // Установка статического экземпляра
    instance = this;
    
    // Настройка пинов
    pinMode(_l_dir, OUTPUT);
    pinMode(_l_speed, OUTPUT);
    pinMode(_r_dir, OUTPUT);
    pinMode(_r_speed, OUTPUT);
    pinMode(_l_line, INPUT);
    pinMode(_r_line, INPUT);
    pinMode(_buzzer_pin, OUTPUT);
    pinMode(_left_phase_a, INPUT);
    pinMode(_left_phase_b, INPUT);
    pinMode(_right_phase_a, INPUT);
    pinMode(_right_phase_b, INPUT);
    
    // Настройка прерываний
    attachInterrupt(digitalPinToInterrupt(_left_phase_a), left_enc_handler, RISING);
    attachInterrupt(digitalPinToInterrupt(_right_phase_a), right_enc_handler, RISING);
}

// Обработчики прерываний
void RobotFunctions::left_enc_handler() {
    if (instance) {
        instance->left_enc_phase_a();
    }
}

void RobotFunctions::right_enc_handler() {
    if (instance) {
        instance->right_enc_phase_a();
    }
}

void RobotFunctions::left_enc_phase_a() {
    if (digitalRead(_left_phase_b)) {
        left_curr_pos--;
    } else {
        left_curr_pos++;
    }
}

void RobotFunctions::right_enc_phase_a() {
    if (digitalRead(_right_phase_b)) {
        right_curr_pos++;
    } else {
        right_curr_pos--;
    }
}

// Остальные функции реализации (go, stopp, reset_enc и т.д.)
// ... (реализация всех объявленных методов)

void RobotFunctions::playMelody() {
    int melody[] = {NOTE_C4, NOTE_D4, NOTE_E4, NOTE_F4, NOTE_G4, NOTE_A4, NOTE_B4};
    int notesCount = sizeof(melody) / sizeof(melody[0]);
    
    for (int i = 0; i < notesCount; i++) {
        tone(_buzzer_pin, melody[i], NOTE_DURATION);
        delay(NOTE_DURATION + PAUSE_BETWEEN_NOTES);
    }
}